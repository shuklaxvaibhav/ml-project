import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import LabelEncoder
import joblib

print("1. Loading the Student Dataset...")
df = pd.read_csv('Final_PDF_Aligned_Student_Data.csv')

print("2. Preprocessing & Cleaning Data...")
encoder = LabelEncoder()
text_columns = ['Gender', 'Department', 'Assignment Submission Status', 'Stress Level', 'Participation in Extracurricular Activities']

for col in text_columns:
    df[col] = encoder.fit_transform(df[col])

print("3. Selecting Features and Target Variable...")
X = df.drop(columns=['Student ID', 'Final Examination Marks', 'Performance Level'])

y = df['Final Examination Marks']

print("4. Splitting the Dataset into Train and Test Data...")
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

print("5. Training the Machine Learning Model (Random Forest)...")
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

print("6. Evaluating Model Accuracy...")
predictions = model.predict(X_test)

mae = mean_absolute_error(y_test, predictions)
rmse = np.sqrt(mean_squared_error(y_test, predictions))
r2 = r2_score(y_test, predictions)

print(f" -> Mean Absolute Error (MAE): {mae:.2f}")
print(f" -> Root Mean Squared Error (RMSE): {rmse:.2f}")
print(f" -> R² Score: {r2:.2f} (closer to 1.0 is better!)")

print("7. Saving the Trained ML Model...")
joblib.dump(model, 'student_model.pkl')
joblib.dump(X.columns.tolist(), 'model_columns.pkl') # Saving the column names for the dashboard

print("SUCCESS! 'student_model.pkl' is ready.")