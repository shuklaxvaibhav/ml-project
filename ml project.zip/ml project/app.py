import streamlit as st
import pandas as pd
import joblib

model = joblib.load('student_model.pkl')
model_columns = joblib.load('model_columns.pkl')

st.title("🎓 AI Student Success Prediction Platform")
st.write("Enter student details below to predict their Final Examination Marks and Performance Level.")

col1, col2, col3 = st.columns(3)

with col1:
    st.header("Demographics")
    age = st.number_input("Age", 18, 30, 20)
    gender = st.selectbox("Gender", ["female", "male"])
    dept = st.selectbox("Department", ["Computer Science", "Information Technology", "Electronics", "Mechanical", "Civil"])
    sem = st.slider("Semester", 1, 8, 4)

with col2:
    st.header("Academic Data")
    gpa = st.number_input("Previous Semester GPA", 0.0, 10.0, 7.5)
    midterm = st.number_input("Midterm Marks", 0, 100, 75)
    assign = st.number_input("Assignment Scores", 0, 100, 80)
    quiz = st.number_input("Quiz Scores", 0, 100, 75)
    prac = st.number_input("Practical/Lab Marks", 0, 100, 80)

with col3:
    st.header("Attendance & Habit")
    att = st.slider("Attendance Percentage", 0, 100, 85)
    missed = st.number_input("Classes Missed", 0, 50, 2)
    late = st.number_input("Late Attendance Records", 0, 20, 0)
    study_hrs = st.slider("Daily Study Hours", 0.0, 15.0, 3.0)
    sub_stat = st.selectbox("Assignment Submission", ["Submitted On Time", "Submitted Late", "Not Submitted"])

st.header("Lifestyle Data")
col4, col5, col6, col7 = st.columns(4)

with col4:
    online_hrs = st.slider("Online Learning Hours", 0.0, 10.0, 2.0)
with col5:
    lib_visits = st.number_input("Library Visits (weekly)", 0, 20, 2)
with col6:
    internet = st.slider("Internet Usage Time (hrs)", 0.0, 15.0, 4.0)
with col7:
    sleep = st.slider("Average Sleep Hours", 0.0, 12.0, 7.0)

col8, col9 = st.columns(2)

with col8:
    stress = st.selectbox("Stress Level", ["Low", "Medium", "High"])
with col9:
    extra = st.selectbox("Extracurricular Activities", ["Yes", "No"])

gender_map = {'female': 0, 'male': 1}
dept_map = {'Civil': 0, 'Computer Science': 1, 'Electronics': 2, 'Information Technology': 3, 'Mechanical': 4}
sub_map = {'Not Submitted': 0, 'Submitted Late': 1, 'Submitted On Time': 2}
stress_map = {'High': 0, 'Low': 1, 'Medium': 2}
extra_map = {'No': 0, 'Yes': 1}

if st.button("Predict Final Marks & Get Recommendations", type="primary"):
    input_data = pd.DataFrame([[
        age, gender_map[gender], dept_map[dept], sem, 
        gpa, midterm, assign, quiz, prac,
        att, missed, late, study_hrs, sub_map[sub_stat],
        online_hrs, lib_visits, internet, sleep, 
        stress_map[stress], extra_map[extra]
    ]], columns=model_columns)

    prediction = model.predict(input_data)[0]
    
    if prediction >= 80:
        category, color = "Excellent 🌟", "green"
        recs = ["Keep up the fantastic work! Maintain your current study habits."]
    elif prediction >= 60:
        category, color = "Good 👍", "blue"
        recs = ["You are doing well! Focus on regular library visits to push for 'Excellent'."]
    elif prediction >= 40:
        category, color = "Average ⚠️", "orange"
        recs = ["Increase your daily study hours.", "Ensure you submit all assignments on time to avoid losing easy marks."]
    else:
        category, color = "At Risk ❌", "red"
        recs = ["Critical: Immediate intervention needed. Please schedule a meeting with your academic advisor.", "Focus entirely on improving attendance."]
        
    st.divider()
    st.markdown(f"### Predicted Final Marks: **{prediction:.2f} / 100**")
    st.markdown(f"### Performance Level: <span style='color:{color}'>{category}</span>", unsafe_allow_html=True)
    
    st.subheader("💡 Personalized Recommendations")
    for r in recs:
        st.write(f"- {r}")